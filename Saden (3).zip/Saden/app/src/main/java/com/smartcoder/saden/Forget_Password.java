package com.smartcoder.saden;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.smartcoder.saden.Class.MySingleTon;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Forget_Password extends AppCompatActivity {

    EditText email_,password,newpassword;
    Boolean isChecked = false;
    Boolean isChecked_ = false;
    TextView continu;
    ProgressDialog dialog;
    ImageView confirm_password_view,password_view,finish;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget__password);
        dialog = new ProgressDialog(Forget_Password.this);
        dialog.setCancelable(false);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        dialog.setMessage("Loading...");
        continu= (TextView) findViewById(R.id.continu);
        email_ = (EditText) findViewById(R.id.textEmail);
        password = (EditText) findViewById(R.id.textpassword);
        newpassword = (EditText) findViewById(R.id.password);
        password_view = (ImageView) findViewById(R.id.password_view);
        confirm_password_view= (ImageView) findViewById(R.id.password_);

        confirm_password_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!isChecked_) {
                    newpassword.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    isChecked_ = true;
                } else {
                    newpassword.setInputType(129);
                    isChecked_ = false;
                }
            }
        });
        password_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!isChecked) {
                    password.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    isChecked = true;
                } else {
                    password.setInputType(129);
                    isChecked = false;
                }
            }
        });


        continu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (email_.getText().toString().isEmpty()){

                    Toast.makeText(Forget_Password.this,R.string.empty_email,Toast.LENGTH_SHORT).show();
                }
                else if (isEmailValid(email_.getText().toString())){

                    Toast.makeText(Forget_Password.this,R.string.not_valid_email,Toast.LENGTH_SHORT).show();
                }
                else if (password.getText().toString().isEmpty()){
                    Toast.makeText(Forget_Password.this,R.string.empty_old_password,Toast.LENGTH_SHORT).show();
                }
                else if (newpassword.getText().toString().isEmpty()){
                    Toast.makeText(Forget_Password.this,R.string.empty_new_password,Toast.LENGTH_SHORT).show();
                }
                else {
                    dialog.show();
                    ext(email_.getText().toString(),newpassword.getText().toString());
                }
            }
        });





    }



    void ext(final String email, final String password) {
        {

            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://madarnets.com/WS/SadnWSAndroid.asmx/RegisterNewCustomer", new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {

                    Log.e("JSON Response", s);
                    dialog.dismiss();
                    if (s.equals("0")){
                        Toast.makeText(Forget_Password.this,R.string.changed_password,Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else if (s.equals("-1")){
                        Toast.makeText(Forget_Password.this,R.string.wrong_email,Toast.LENGTH_SHORT).show();
                    }
                    else if (s.equals("-2")){
                        Toast.makeText(Forget_Password.this,R.string.wrong_old_password,Toast.LENGTH_SHORT).show();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {

                    //loading.dismiss();
                    Log.e("JSON Error", volleyError.toString());
                    Toast.makeText(Forget_Password.this, "Error:" + volleyError.toString(), Toast.LENGTH_LONG).show();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("KEY","qsefthuko!@#456&*(PLIJYGRDWA");
                    parms.put("emailAddress", email + "");
                    parms.put("password", password + "");
                    return parms;
                }
            };

            stringRequest.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 10000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 10000;
                }

                @Override
                public void retry(VolleyError volleyError) throws VolleyError {

                }
            });
            MySingleTon.getInstance(Forget_Password.this).addToRequestQueue(stringRequest);
        }
    }
    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
