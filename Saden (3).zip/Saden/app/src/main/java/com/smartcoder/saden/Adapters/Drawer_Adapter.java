package com.smartcoder.saden.Adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.edmodo.rangebar.RangeBar;
import com.google.android.gms.vision.text.Text;
import com.smartcoder.saden.Objects.Drawer_Object;
import com.smartcoder.saden.Objects.Favorite_Object;
import com.smartcoder.saden.R;

import java.awt.font.NumericShaper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Adeel on 10/13/2017.
 */

public class Drawer_Adapter extends BaseExpandableListAdapter {

    private Context context;
    private List<String> List_data_Header;
    private HashMap<String,List<String>> hashMap;
    public Drawer_Adapter(Context context, List<String> list_data_Header, HashMap<String,List<String>> hashMap){

        this.context = context;
        this.List_data_Header = list_data_Header;
        this.hashMap = hashMap;
    }
    @Override
    public int getGroupCount() {
        return List_data_Header.size();
    }

    @Override
    public int getChildrenCount(int i) {
        return hashMap.get(List_data_Header.get(i)).size();
    }

    @Override
    public Object getGroup(int i) {
        return List_data_Header.get(i);
    }

    @Override
    public Object getChild(int i, int i1) {
        return hashMap.get(List_data_Header.get(i)).get(i1);
    }

    @Override
    public long getGroupId(int i) {
        return 0;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int i, boolean b, View view, ViewGroup viewGroup) {

        String headerTitel = (String)getGroup(i);
        if (view == null){

            if (headerTitel.equals("header")) {

                LayoutInflater inflater = (LayoutInflater)this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.drawer_head,null);

            }
            else if (headerTitel.equals("range")){
                LayoutInflater inflater = (LayoutInflater)this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.price,null);

                final TextView left_index = (TextView) view.findViewById(R.id.left_price_value);
                final TextView right_index = (TextView) view.findViewById(R.id.right_price_value);
                RangeBar rangebar1 = (RangeBar) view.findViewById(R.id.rangebar1);
                rangebar1.setOnRangeBarChangeListener(new RangeBar.OnRangeBarChangeListener() {
                    @Override
                    public void onIndexChangeListener(RangeBar rangeBar, int i, int i1) {
                        left_index.setText(i+"");
                        right_index.setText(i1+"");
                    }
                });
            }
            else{
                LayoutInflater inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.drawer_cat_and_country, null);
                TextView cat = (TextView) view.findViewById(R.id.cat);
                cat.setText(headerTitel);
            }

        }



        return view;
    }

    @Override
    public View getChildView(int i, int i1, boolean b, View view, ViewGroup viewGroup) {
        String child_text = (String)getChild(i,i1);
            LayoutInflater inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.drawer_expandable_list_item, null);
            TextView expandeable_list_item = (TextView) view.findViewById(R.id.expandeable_list_item);
            expandeable_list_item.setText(child_text);

        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return false;
    }
}
/*RangeBar rangebar;
            rowView = inflater.inflate(R.layout.price,null,true);
            rangebar = (RangeBar) rowView.findViewById(R.id.rangebar1);
            final TextView left_price_value,right_price_value;
            right_price_value = (TextView) rowView.findViewById(R.id.right_price_value);
            left_price_value= (TextView) rowView.findViewById(R.id.left_price_value);
            rangebar.setOnRangeBarChangeListener(new RangeBar.OnRangeBarChangeListener() {
                @Override
                public void onIndexChangeListener(RangeBar rangeBar, int leftThumbIndex, int rightThumbIndex) {
                    left_price_value.setText("" + leftThumbIndex);
                    right_price_value.setText("" + rightThumbIndex);
                }
            });
        }

        return rowView;*/