package com.smartcoder.saden.Objects;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Adeel on 11/01/2017.
 */

public class Categories {
    String BeautyCategoryID = "";
    String NameAr = "";
    String NameEn = "";
    String  DescriptionAr= "";
    String  DescriptionEn= "";
    String ImageArID = "";
    String listitem = "";

    public String getListitem() {
        return listitem;
    }

    public void setListitem(String listitem) {
        this.listitem = listitem;
    }

    public List<Sub_Category> getSub_categories() {
        return sub_categories;
    }

    public void setSub_categories(List<Sub_Category> sub_categories) {
        this.sub_categories = sub_categories;
    }

    String ImageEnID = "";
    List<Sub_Category> sub_categories = new ArrayList<>();

    public String getBeautyCategoryID() {
        return BeautyCategoryID;
    }

    public void setBeautyCategoryID(String beautyCategoryID) {
        BeautyCategoryID = beautyCategoryID;
    }

    public String getNameAr() {
        return NameAr;
    }

    public void setNameAr(String nameAr) {
        NameAr = nameAr;
    }

    public String getNameEn() {
        return NameEn;
    }

    public void setNameEn(String nameEn) {
        NameEn = nameEn;
    }

    public String getDescriptionAr() {
        return DescriptionAr;
    }

    public void setDescriptionAr(String descriptionAr) {
        DescriptionAr = descriptionAr;
    }

    public String getDescriptionEn() {
        return DescriptionEn;
    }

    public void setDescriptionEn(String descriptionEn) {
        DescriptionEn = descriptionEn;
    }

    public String getImageArID() {
        return ImageArID;
    }

    public void setImageArID(String imageArID) {
        ImageArID = imageArID;
    }

    public String getImageEnID() {
        return ImageEnID;
    }

    public void setImageEnID(String imageEnID) {
        ImageEnID = imageEnID;
    }

}
