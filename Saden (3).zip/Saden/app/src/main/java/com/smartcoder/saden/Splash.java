package com.smartcoder.saden;

import android.*;
import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.smartcoder.saden.Class.AppLocationService;
import com.smartcoder.saden.Class.JSONParser;
import com.smartcoder.saden.Class.MySingleTon;
import com.smartcoder.saden.Objects.Advertisement;
import com.smartcoder.saden.Objects.Categories;
import com.smartcoder.saden.Objects.Sub_Category;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.Permission;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import cz.msebera.android.httpclient.NameValuePair;
import cz.msebera.android.httpclient.message.BasicNameValuePair;

import static java.security.AccessController.getContext;

public class Splash extends AppCompatActivity {

    TextView saden;
    AppLocationService appLocationService;
    double latitude, longitude;
    JSONParser jsonParser = new JSONParser();
    int i = 0;
    String[] request_permissions = new String[2];

    int loading_ = -2;
    int array_length = -1;
    static int bitmap_loading = -1;
    static Boolean onstop = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        saden = (TextView) findViewById(R.id.saden);

        call_animation();

    }

    void call_animation() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                if (!onstop) {
                    ImageViewAnimatedChange(getApplicationContext(), saden);
                    call_animation();
                }
            }
        }, 1000);

    }

    public static void ImageViewAnimatedChange(Context c, final TextView v) {
        final Animation anim_out = AnimationUtils.loadAnimation(c, android.R.anim.fade_out);
        final Animation anim_in = AnimationUtils.loadAnimation(c, android.R.anim.fade_in);
        anim_out.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                anim_in.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {
                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                    }
                });
                if (!onstop)
                v.startAnimation(anim_in);
            }
        });
        if (!onstop)
        v.startAnimation(anim_out);
    }

    void ext(final double lat, final double lon) {
        {

            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://madarnets.com/WS/SadnWSAndroid.asmx/GetBeautyCategoriesAndAdvertisements", new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {

                    Log.e("JSON Response", s);


                    /*[{"AdvertisementID":1,"BeautyCenterID":1,"IsInternalAd":true,"ImageArID":"http://www.madarnets.com/GetImage.ashx?id=2017102521571732612662.png","ImageEnID":"http://www.madarnets.com/GetImage.ashx?id=2017102521571733557513.png","WebLinkAr":"","WebLinkEn":"","BeautyCenterNameAr":"مركز1","BeautyCenterNameEn":"Center1"}]*/

                    try {

                        JSONArray array = new JSONArray(s);

                        Utils.categories_list = new ArrayList<>();
                        Categories categorie = new Categories();
                        Utils.ads = new ArrayList<>();
                        categorie.setListitem("slider");
                        Utils.categories_list.add(categorie);

                        for (int i=0;i<array.length();i++) {
                            JSONArray innerArray = array.optJSONArray(i);
                            for (int j = 0; j < innerArray.length(); j++) {
                                JSONObject object_ = innerArray.getJSONObject(j);
                                Categories categories = new Categories();

                                if (object_.has("AdvertisementID")) {
                                    Advertisement advertisement = new Advertisement();
                                    advertisement.setAdvertisementID(object_.getString("AdvertisementID"));
                                    advertisement.setBeautyCenterID(object_.getString("BeautyCenterID"));
                                    advertisement.setIsInternalAd(object_.getString("IsInternalAd"));
                                    advertisement.setBeautyCenterNameAr(object_.getString("BeautyCenterNameAr"));
                                    advertisement.setBeautyCenterNameEn(object_.getString("BeautyCenterNameEn"));
                                    advertisement.setImageEnID(object_.getString("ImageEnID"));
                                    advertisement.setImageArID(object_.getString("ImageArID"));
                                    advertisement.setWebLinkAr(object_.getString("WebLinkAr"));
                                    advertisement.setWebLinkEn(object_.getString("WebLinkEn"));
                                    Utils.ads.add(advertisement);

                                } else {
                                    categories.setListitem("grid");
                                    categories.setImageArID(object_.get("ImageArID").toString());
                                    categories.setNameEn(object_.getString("NameEn"));
                                    categories.setNameAr(object_.getString("NameAr"));
                                    categories.setDescriptionEn(object_.getString("DescriptionEn"));
                                    categories.setDescriptionAr(object_.getString("DescriptionAr"));
                                    categories.setBeautyCategoryID(object_.getString("BeautyCategoryID"));
                                    List<Sub_Category> itemListM = new ArrayList<>();
                                    JSONArray jsonArray = object_.getJSONArray("BeautyCentersList");
                                    for (i = 0; i < jsonArray.length(); i++) {
                                        JSONObject object = jsonArray.getJSONObject(i);
                                        Sub_Category item = new Sub_Category();
                                        item.setBeautyCenterID(object.getString("BeautyCenterID"));
                                        item.setNameEn(object.getString("NameEn"));
                                        item.setNameAr(object.getString("NameAr"));
                                        item.setCityNameAr(object.getString("CityNameAr"));
                                        item.setCityNameEn(object.getString("CityNameEn"));
                                        item.setMobileNo(object.getString("MobileNo"));
                                        item.setLandlineNo(object.getString("LandlineNo"));
                                        item.setFaxNo(object.getString("FaxNo"));
                                        item.setPOBox(object.getString("POBox"));
                                        item.setPostSymbol(object.getString("PostSymbol"));
                                        item.setStreetNameAr(object.getString("StreetNameAr"));
                                        item.setStreetNameEn(object.getString("StreetNameEn"));
                                        item.setDetailedAddressAr(object.getString("DetailedAddressAr"));
                                        item.setDetailedAddressEn(object.getString("DetailedAddressEn"));
                                        item.setLatValue(object.getString("LatValue"));
                                        item.setLonValue(object.getString("LonValue"));
                                        item.setWorkingHoursStart(object.getString("WorkingHoursStart"));
                                        item.setWorkingHoursEnd(object.getString("WorkingHoursEnd"));
                                        item.setFacebookAccount(object.getString("FacebookAccount"));
                                        item.setInstagramAccount(object.getString("InstagramAccount"));
                                        item.setTwitterAccount(object.getString("TwitterAccount"));
                                        item.setYoutubeAccount(object.getString("YoutubeAccount"));
                                        item.setSnapchatAccount(object.getString("SnapchatAccount"));
                                        item.setNotes(object.getString("Notes"));
                                        item.setBeautyCenterImagesList(object.getString("BeautyCenterImagesList"));
                                        itemListM.add(item);
                                    }
                                    categories.setSub_categories(itemListM);
                                    Utils.categories_list.add(categories);
                                }
                            }
                        }
                        Intent intent = new Intent(Splash.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                        catch (JSONException e) {
                        e.printStackTrace();
                        Log.e("njfndj",e.toString());
                        Toast.makeText(Splash.this,""+e,Toast.LENGTH_LONG).show();
                    }
                    Log.d("JSON testing", "testing");
                    /*Intent intent = new Intent(Splash.this, MainActivity.class);
                    startActivity(intent);
                    finish();*/
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {

                    //loading.dismiss();
                    Log.e("JSON Error", volleyError.toString());
                    Toast.makeText(Splash.this, "Error:" + volleyError.toString(), Toast.LENGTH_LONG).show();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("lat", lat + "");
                    parms.put("lon", lon + "");
                    return parms;
                }
            };

            stringRequest.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 10000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 10000;
                }

                @Override
                public void retry(VolleyError volleyError) throws VolleyError {

                }
            });
            MySingleTon.getInstance(Splash.this).addToRequestQueue(stringRequest);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


        switch (requestCode) {
            case 123: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //If user presses allow
                    Toast.makeText(Splash.this, "Permission granted!", Toast.LENGTH_SHORT).show();
                    statusCheck();
                } else {
                    //If user presses deny
                    Toast.makeText(Splash.this, "Permission denied", Toast.LENGTH_SHORT).show();
                }
                break;
            }
        }
    }
        public static Bitmap getBitmapFromURL(String src) {
            try {
                URL url = new URL(src);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                Bitmap myBitmap = BitmapFactory.decodeStream(input);
                if (myBitmap!=null){
                    bitmap_loading ++;
                }
                return myBitmap;
            } catch (IOException e) {
                // Log exception
                return null;
            }
        }
    public void statusCheck() {
        Log.d("status_check","status_check");
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            //buildAlertMessageNoGps();
            ext(0, 0);
            Log.d("dialog________","bbbb");

        }
        else{
            Log.d("network________","aaaa");
            appLocationService = new AppLocationService(Splash.this);
            Location newlocation = appLocationService.getLocation(LocationManager.NETWORK_PROVIDER);
            if (newlocation != null) {
                ext(newlocation.getLatitude(), newlocation.getLongitude());
            }
        }
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        Log.d("activity","aaaa");
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                        ext(0, 0);
                       // Toast.makeText(Splash.this,"We cannot proceed further",Toast.LENGTH_SHORT).show();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("resume","ttttt");

        SharedPreferences preferences = getSharedPreferences("lang",MODE_PRIVATE);
        if (preferences.getString("lang","").equals("en")){
            String languageToLoad = "en";
            Locale locale = new Locale(languageToLoad);
            Locale.setDefault(locale);

            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config,
                    getBaseContext().getResources().getDisplayMetrics());

        }
        else {
            String languageToLoad = "de";
            Locale locale = new Locale(languageToLoad);
            Locale.setDefault(locale);

            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config,
                    getBaseContext().getResources().getDisplayMetrics());

        }
        //Toast.makeText(Splash.this,"resum",Toast.LENGTH_SHORT).show();
        int PERMISSION_ALL = 1;
        String[] PERMISSIONS = {Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION/*, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_SMS, Manifest.permission.CAMERA*/};

        if(!hasPermissions(this, PERMISSIONS)){
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }

        if (ContextCompat.checkSelfPermission(Splash.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED&&ContextCompat.checkSelfPermission(Splash.this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            if (isNetworkAvailable()) {
                Log.d("internet_____________","ttttt");
                statusCheck();
            }
            else {
                Toast.makeText(Splash.this,"Internet is not available...",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        onstop = true;
    }




    public static boolean hasPermissions(Context context, String... permissions) {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
