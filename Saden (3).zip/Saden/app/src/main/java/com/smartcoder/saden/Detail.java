package com.smartcoder.saden;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import com.smartcoder.saden.Class.MySingleTon;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Detail extends AppCompatActivity {

    SliderLayout mDemoSlider;
    public static Activity fa;
    TextView timing,description,phone,landline,FaxNo,POBox,Detail_Address,header,city,note;
    ImageView favorite___,share;
    private ProgressDialog mProgressDialog;
    ImageView finish;
    ImageView twitter,google_button,facebook,youtube,linkdin,instagram;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        fa = this;
        facebook = (ImageView) findViewById(R.id.facebook);
        youtube =  (ImageView) findViewById(R.id.youtube);
        linkdin = (ImageView) findViewById(R.id.linkdin);
        instagram = (ImageView) findViewById(R.id.instagram);
        city = (TextView) findViewById(R.id.city);
        google_button = (ImageView) findViewById(R.id.google_button);
        twitter = (ImageView) findViewById(R.id.twitter);
        finish = (ImageView) findViewById(R.id.finish);
        favorite___ = (ImageView) findViewById(R.id.favorite___);
        share = (ImageView) findViewById(R.id.share);
        header = (TextView) findViewById(R.id.header);
        note = (TextView) findViewById(R.id.note);
//        description = (TextView) findViewById(R.id.description);
        phone = (TextView) findViewById(R.id.phone);
        timing = (TextView) findViewById(R.id.timing);
        landline = (TextView) findViewById(R.id.landline);
        FaxNo = (TextView) findViewById(R.id.FaxNo);
        POBox = (TextView) findViewById(R.id.POBox);
        Detail_Address = (TextView) findViewById(R.id.Detail_Address);

        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_link(Utils.sub_category.getFacebookAccount());
            }
        });

        SharedPreferences preferences = getSharedPreferences("lang",Context.MODE_PRIVATE);
        if (preferences.getString("lang","ar").equals("ar")){
            phone.setGravity(Gravity.RIGHT);
            timing.setGravity(Gravity.RIGHT);
            landline.setGravity(Gravity.RIGHT);
            FaxNo.setGravity(Gravity.RIGHT);
            POBox.setGravity(Gravity.RIGHT);
            city.setGravity(Gravity.RIGHT);
            Detail_Address.setGravity(Gravity.RIGHT);
            note.setGravity(Gravity.RIGHT);

            timing.setText(Utils.sub_category.getWorkingHoursStart()+" :"+Utils.sub_category.getWorkingHoursEnd());
//        description.setText(Utils.sub_category.getDescriptionAr());
            phone.setText(Utils.sub_category.getMobileNo());
            landline.setText(Utils.sub_category.getLandlineNo());
            FaxNo.setText(Utils.sub_category.getFaxNo());
            POBox.setText(Utils.sub_category.getPOBox());
            city.setText(Utils.sub_category.getCityNameAr());
            Detail_Address.setText(Utils.sub_category.getDetailedAddressAr());
            header.setText(Utils.sub_category.getNameAr());
            mDemoSlider = (SliderLayout) findViewById(R.id.slider);
            note.setText(Utils.sub_category.getNotes());
        }
        else {
            phone.setGravity(Gravity.START);
            timing.setGravity(Gravity.START);
            landline.setGravity(Gravity.START);
            FaxNo.setGravity(Gravity.START);
            POBox.setGravity(Gravity.START);
            city.setGravity(Gravity.START);
            Detail_Address.setGravity(Gravity.START);
            note.setGravity(Gravity.START);

            timing.setText(Utils.sub_category.getWorkingHoursStart()+" :"+Utils.sub_category.getWorkingHoursEnd());
//        description.setText(Utils.sub_category.getDescriptionAr());
            phone.setText(Utils.sub_category.getMobileNo());
            landline.setText(Utils.sub_category.getLandlineNo());
            FaxNo.setText(Utils.sub_category.getFaxNo());
            POBox.setText(Utils.sub_category.getPOBox());
            city.setText(Utils.sub_category.getCityNameEn());
            Detail_Address.setText(Utils.sub_category.getDetailedAddressEn());
            header.setText(Utils.sub_category.getNameEn());
            mDemoSlider = (SliderLayout) findViewById(R.id.slider);
            note.setText(Utils.sub_category.getNotes());
        }

        google_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*open_link(Utils.sub_category.get);*/
            }
        });
        twitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_link(Utils.sub_category.getTwitterAccount());
            }
        });
        youtube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_link(Utils.sub_category.getYoutubeAccount());
            }
        });
        instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_link(Utils.sub_category.getInstagramAccount());
            }
        });
        google_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_link(Utils.sub_category.getSnapchatAccount());
            }
        });

        HashMap<String, String> url_maps = new HashMap<String, String>();

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "My application name");
                startActivity(Intent.createChooser(i, "choose one"));
            }
        });

        favorite___.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences preferences = getSharedPreferences("user_id",MODE_PRIVATE);
                if (preferences.getString("user_id","-1").equals("-1")){
                    //Toast.makeText(Detail.this,"You Are not Loged In...Please Login First",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Detail.this,Sign_up.class);
                    startActivity(intent);
                }
                else {
                    ext(preferences.getString("user_id", ""), Utils.sub_category.getBeautyCenterID());
                    /*if (favorite___.getResources().equals(R.mipmap.image_1)) {
                        ext(preferences.getString("user_id", ""), Utils.sub_category.getBeautyCenterID());
                    }
                    else {
                        ext_(preferences.getString("user_id", ""), Utils.sub_category.getBeautyCenterID());
                    }*/
                }

            }
        });

        //Toast.makeText(Detail.this,""+Utils.sub_category.getBeautyCenterImagesList(),Toast.LENGTH_SHORT).show();


        JSONArray array = null;
        try {
            array = new JSONArray(Utils.sub_category.getBeautyCenterImagesList());
            for(int i=0;i<array.length();i++) {
                JSONObject object = new JSONObject();
                object =  array.getJSONObject(i);
                url_maps.put("", object.toString());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        for (String name : url_maps.keySet()) {
            TextSliderView textSliderView = new TextSliderView(this);
            textSliderView
                    .description(name)
                    .image(url_maps.get(name))
                    .setScaleType(BaseSliderView.ScaleType.Fit)
                    .setOnSliderClickListener(new BaseSliderView.OnSliderClickListener() {
                        @Override
                        public void onSliderClick(BaseSliderView slider) {

                        }
                    });

            //add your extra information
            textSliderView.bundle(new Bundle());
            textSliderView.getBundle()
                    .putString("extra", name);

            mDemoSlider.addSlider(textSliderView);
        }
        mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Accordion);
        mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
        mDemoSlider.setCustomAnimation(new DescriptionAnimation());
        mDemoSlider.setDuration(4000);
        mDemoSlider.addOnPageChangeListener(new ViewPagerEx.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }
    private void showProgressDialog() {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(Detail.this);
            mProgressDialog.setMessage("loading");
            mProgressDialog.setIndeterminate(true);
        }

        mProgressDialog.show();
    }

    private void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.hide();
        }
    }

    void ext(final String user_id,final String beautycenter_id) {
        {

            showProgressDialog();
            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://madarnets.com/WS/SadnWSAndroid.asmx/AddCustomerFavorite", new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {

                    hideProgressDialog();
                    Log.e("JSON Response", s);
                    if (s.equals("-1")){
                        Toast.makeText(Detail.this,R.string.already_added_favorite,Toast.LENGTH_SHORT).show();
                        favorite___.setImageResource(R.mipmap.image_1_);
                    }
                    else if (s.equals("-2")){
                        Toast.makeText(Detail.this,R.string.unknown_error,Toast.LENGTH_SHORT).show();
                    }
                    else {
                        favorite___.setImageResource(R.mipmap.image_1_);
                        //added to favorite

                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {

                    //loading.dismiss();
                    Log.e("JSON Error", volleyError.toString());
                    Toast.makeText(Detail.this, "Error:" + volleyError.toString(), Toast.LENGTH_LONG).show();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("KEY","qsefthuko!@#456&*(PLIJYGRDWA");
                    parms.put("customerID", user_id );
                    parms.put("beautyCenterID", beautycenter_id );
                    return parms;
                }
            };

            stringRequest.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 10000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 10000;
                }

                @Override
                public void retry(VolleyError volleyError) throws VolleyError {

                }
            });
            MySingleTon.getInstance(Detail.this).addToRequestQueue(stringRequest);
        }
    }

    private boolean appInstalledOrNot(String uri) {
        PackageManager pm = getPackageManager();
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
        }

        return false;
    }
    //method to get the right URL to use in the intent
    public String getFacebookPageURL(Context context,String facebook_url) {
        String FACEBOOK_URL = facebook_url;
        String FACEBOOK_PAGE_ID = "YourPageName";
        PackageManager packageManager = context.getPackageManager();
        try {
            int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
            if (versionCode >= 3002850) { //newer versions of fb app
                return "fb://facewebmodal/f?href=" + FACEBOOK_URL;
            } else { //older versions of fb app
                return "fb://page/" + FACEBOOK_PAGE_ID;
            }
        } catch (PackageManager.NameNotFoundException e) {
            return FACEBOOK_URL; //normal web url
        }
    }
    void ext_(final String user_id, final String product_id) {
        {

            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://madarnets.com/WS/SadnWSAndroid.asmx/DeleteCustomerFavorite", new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {

                    //dialog.dismiss();
                    Log.e("JSON Response", s);
                    if (s.equals("-1")){
                        Toast.makeText(Detail.this,R.string.no_rec_found,Toast.LENGTH_SHORT).show();
                    }
                    else if (s.equals("-2")){
                        Toast.makeText(Detail.this,R.string.unknown_error,Toast.LENGTH_SHORT).show();
                    }
                    else if (s.equals("0")){
                        favorite___.setImageResource(R.mipmap.image_1);
                    }


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {

                    //loading.dismiss();
                    Log.e("JSON Error", volleyError.toString());
                    Toast.makeText(Detail.this, "Error:" + volleyError.toString(), Toast.LENGTH_LONG).show();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("KEY","qsefthuko!@#456&*(PLIJYGRDWA");
                    parms.put("customerID", user_id + "");
                    parms.put("beautyCenterID", product_id + "");
                    return parms;
                }
            };

            stringRequest.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 10000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 10000;
                }

                @Override
                public void retry(VolleyError volleyError) throws VolleyError {

                }
            });
            MySingleTon.getInstance(Detail.this).addToRequestQueue(stringRequest);
        }
    }

    void open_link(String s){
        if (s!=null&&s!=""){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://"+s));
        startActivity(browserIntent);
        }
        else {
            Toast.makeText(Detail.this,R.string.empty_link,Toast.LENGTH_SHORT).show();
        }
    }

}
