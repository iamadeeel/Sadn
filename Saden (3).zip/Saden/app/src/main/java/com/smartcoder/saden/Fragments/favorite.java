package com.smartcoder.saden.Fragments;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.nhaarman.listviewanimations.appearance.AnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.SwingBottomInAnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.SwingRightInAnimationAdapter;
import com.smartcoder.saden.Adapters.favorite_Adapter;
import com.smartcoder.saden.Class.MySingleTon;
import com.smartcoder.saden.Detail;
import com.smartcoder.saden.MainActivity;
import com.smartcoder.saden.Objects.Categories;
import com.smartcoder.saden.Objects.Favorite_Object;
import com.smartcoder.saden.Objects.Sub_Category;
import com.smartcoder.saden.R;
import com.smartcoder.saden.Splash;
import com.smartcoder.saden.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class favorite extends Fragment {
    ListView listView;
    List<Sub_Category> list = new ArrayList<>();
    favorite_Adapter adapter;
    ProgressBar progressBar;
    TextView not_loged_in;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_favorite, container, false);
        listView = (ListView) view.findViewById(R.id.list_view);
        progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
        not_loged_in = (TextView) view.findViewById(R.id.not_loged_in);
        SharedPreferences preferences = getActivity().getSharedPreferences("user_id",Context.MODE_PRIVATE);
        if (preferences.getString("user_id","-1").equals("-1")){
            listView.setVisibility(View.GONE);
            progressBar.setVisibility(View.GONE);
            not_loged_in.setVisibility(View.VISIBLE);
        }
        else {
            ext(preferences.getString("user_id",""));
        }

/*        for (int i = 0; i < 10; i++) {
            Favorite_Object object = new Favorite_Object();
            list.add(object);
        }
        adapter = new favorite_Adapter(getActivity(), list);

        AnimationAdapter mAnimAdapter = new SwingRightInAnimationAdapter(adapter);*//*
        AnimationAdapter mAnimAdapter = new SwingBottomInAnimationAdapter(new SwingRightInAnimationAdapter(adapter));*//*
        mAnimAdapter.setAbsListView(listView);
        listView.setAdapter(mAnimAdapter);*/
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Utils.sub_category = list.get(i);
                Intent intent = new Intent(getActivity(), Detail.class);
                startActivity(intent);
            }
        });

        return view;

    }

    void ext(final String costumer_id) {
        {

            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://madarnets.com/WS/SadnWSAndroid.asmx/GetCustomerFavorites", new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {

                    Log.e("JSON Response", s);

                    try {

                        JSONArray array = new JSONArray(s);

                                for (int i = 0; i < array.length(); i++) {

                                    JSONObject object = array.getJSONObject(i);
                                    Sub_Category item = new Sub_Category();
                                    item.setBeautyCenterID(object.getString("BeautyCenterID"));
                                    item.setNameEn(object.getString("NameEn"));
                                    item.setNameAr(object.getString("NameAr"));
                                    item.setCityNameAr(object.getString("CityNameAr"));
                                    item.setCityNameEn(object.getString("CityNameEn"));
                                    item.setMobileNo(object.getString("MobileNo"));
                                    item.setLandlineNo(object.getString("LandlineNo"));
                                    item.setFaxNo(object.getString("FaxNo"));
                                    item.setPOBox(object.getString("POBox"));
                                    item.setPostSymbol(object.getString("PostSymbol"));
                                    item.setStreetNameAr(object.getString("StreetNameAr"));
                                    item.setStreetNameEn(object.getString("StreetNameEn"));
                                    item.setDetailedAddressAr(object.getString("DetailedAddressAr"));
                                    item.setDetailedAddressEn(object.getString("DetailedAddressEn"));
                                    item.setLatValue(object.getString("LatValue"));
                                    item.setLonValue(object.getString("LonValue"));
                                    item.setWorkingHoursStart(object.getString("WorkingHoursStart"));
                                    item.setWorkingHoursEnd(object.getString("WorkingHoursEnd"));
                                    item.setFacebookAccount(object.getString("FacebookAccount"));
                                    item.setInstagramAccount(object.getString("InstagramAccount"));
                                    item.setTwitterAccount(object.getString("TwitterAccount"));
                                    item.setYoutubeAccount(object.getString("YoutubeAccount"));
                                    item.setSnapchatAccount(object.getString("SnapchatAccount"));
                                    item.setNotes(object.getString("Notes"));
                                    item.setBeautyCenterImagesList(object.getString("BeautyCenterImagesList"));
                                    list.add(item);

                        }
                        favorite_Adapter adapter = new favorite_Adapter(getActivity(),list);
                        AnimationAdapter mAnimAdapter = new SwingBottomInAnimationAdapter(new SwingRightInAnimationAdapter(adapter));
                        mAnimAdapter.setAbsListView(listView);
                        listView.setAdapter(mAnimAdapter);
                        progressBar.setVisibility(View.GONE);
                        listView.setVisibility(View.VISIBLE);
                    }

                    catch (JSONException e) {
                        e.printStackTrace();
                        Log.e("njfndj",e.toString());
                        Toast.makeText(getActivity(),""+e,Toast.LENGTH_LONG).show();
                    }


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {

                    //loading.dismiss();
                    Log.e("JSON Error", volleyError.toString());
                    Toast.makeText(getActivity(), "Error:" + volleyError.toString(), Toast.LENGTH_LONG).show();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("KEY", "qsefthuko!@#456&*(PLIJYGRDWA");
                    parms.put("customerID", costumer_id);
                    return parms;
                }
            };

            stringRequest.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 10000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 10000;
                }

                @Override
                public void retry(VolleyError volleyError) throws VolleyError {

                }
            });
            MySingleTon.getInstance(getActivity()).addToRequestQueue(stringRequest);
        }

    }
    void show_message(String msg){
        Toast.makeText(getActivity(),""+msg,Toast.LENGTH_SHORT).show();
    }
}
