package com.smartcoder.saden.Objects;

/**
 * Created by Adeel on 10/13/2017.
 */

public class Drawer_Object {
    int i;

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
}
