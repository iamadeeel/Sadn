package com.smartcoder.saden.Fragments;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.smartcoder.saden.R;
import com.smartcoder.saden.Utils;

import java.io.IOException;
import java.net.URL;

public class location extends Fragment implements OnMapReadyCallback {

    GoogleMap googleMap_;
    MapView mapView;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view  = inflater.inflate(R.layout.fragment_location, container, false);


        return view;
    }

    @Override
    public void onViewCreated(View view_, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view_, savedInstanceState);

        mapView = (MapView) view.findViewById(R.id.maps);
        if (mapView!=null){
            mapView.onCreate(null);
            mapView.onResume();
            mapView.getMapAsync(this);

        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        MapsInitializer.initialize(getContext());
        googleMap_ = googleMap;
        googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);


        LatLng point = new LatLng(32.8734789, 72.3840373);

        MarkerOptions options = new MarkerOptions();
        options.position(point);
        options.title("Title");
        try {
            URL url = new URL(Utils.categories_list.get(0).getImageArID());
            Bitmap image = BitmapFactory.decodeStream(url.openConnection().getInputStream());
            BitmapDescriptor icon = BitmapDescriptorFactory.fromBitmap(image);
            options.icon(icon);
        } catch(IOException e) {
            System.out.println(e);
        }
        googleMap.addMarker(options);
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(point));
    }
}
