package com.smartcoder.saden;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.smartcoder.saden.Class.MySingleTon;
import com.smartcoder.saden.Fragments.Registration;
import com.smartcoder.saden.Fragments.user;

import java.util.HashMap;
import java.util.Map;

public class Sign_up extends AppCompatActivity {

    TextView login,register;
    View login_view,register_view;
    public static Activity fa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        fa = this;
        login_view = (View) findViewById(R.id.login_view);
        register_view = (View) findViewById(R.id.register_view);
        login = (TextView) findViewById(R.id.login);
        register = (TextView) findViewById(R.id.register);
        final ImageView finish  = (ImageView) findViewById(R.id.finish);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login.setTextColor(Color.parseColor("#47525e"));
                login_view.setBackgroundResource(R.color.darkgrey);
                register.setTextColor(Color.parseColor("#c0ccda"));
                register_view.setBackgroundResource(R.color.lightgrey);
                Fragment fragment_=new user();
                FragmentManager manager_=getSupportFragmentManager();
                FragmentTransaction transaction_=manager_.beginTransaction();
                transaction_.replace(R.id.fragment__,fragment_);
                transaction_.commit();
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                register.setTextColor(Color.parseColor("#47525e"));
                register_view.setBackgroundResource(R.color.darkgrey);
                login.setTextColor(Color.parseColor("#c0ccda"));
                login_view.setBackgroundResource(R.color.lightgrey);
                Fragment fragment_=new Registration();
                FragmentManager manager_=getSupportFragmentManager();
                FragmentTransaction transaction_=manager_.beginTransaction();
                transaction_.replace(R.id.fragment__,fragment_);
                transaction_.commit();
            }
        });

    }
}