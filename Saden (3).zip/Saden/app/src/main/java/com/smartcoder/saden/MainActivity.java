package com.smartcoder.saden;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.smartcoder.saden.Adapters.Drawer_Adapter;
import com.smartcoder.saden.Fragments.Registration;
import com.smartcoder.saden.Fragments.cart;
import com.smartcoder.saden.Fragments.favorite;
import com.smartcoder.saden.Fragments.home;
import com.smartcoder.saden.Fragments.location;
import com.smartcoder.saden.Fragments.user;
import com.smartcoder.saden.Objects.Drawer_Object;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity  {

    static ImageView home;
    static ImageView favorite;
    ImageView more;
    static ImageView location;
    static ImageView cart;
    static ImageView user;
    ImageView exit;
    RelativeLayout home_,favorite_,location_,cart_,user_;
    static TextView home__;
    static TextView favorite__;
    static TextView location__;
    static TextView cart__;
    static TextView user__;
    Fragment fragment,fragment_;
    static RelativeLayout layout_home;
    static RelativeLayout layout2;
    static RelativeLayout layout_user;
    View login_view,register_view;


    TextView login,register;
    static ImageView share;
    RelativeLayout menu_;
    static DrawerLayout mDrawerLayout;
    ExpandableListView mDrawerList;
    List<String> list_data_header;
    HashMap<String,List<String>> hashMap;
    static ImageView local;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        local = (ImageView) findViewById(R.id.local);
        menu_ = (RelativeLayout) findViewById(R.id.menu_);
        share = (ImageView) findViewById(R.id.share);
        home__ = (TextView) findViewById(R.id.home__);
        favorite__ = (TextView) findViewById(R.id.favorite__);
        location__ = (TextView) findViewById(R.id.location__);
        cart__ = (TextView) findViewById(R.id.cart__);
        user__ = (TextView) findViewById(R.id.user__);
        home_ = (RelativeLayout) findViewById(R.id.home_rel);
        favorite_ = (RelativeLayout) findViewById(R.id.favorite_rel);
        location_ = (RelativeLayout) findViewById(R.id.location_rel);
        cart_ = (RelativeLayout) findViewById(R.id.cart_rel);
        user_ = (RelativeLayout) findViewById(R.id.user_rel);
        layout_user = (RelativeLayout) findViewById(R.id.rel_user);
        layout_home = (RelativeLayout) findViewById(R.id.rel);
        layout2 = (RelativeLayout) findViewById(R.id.rel2);
        home = (ImageView) findViewById(R.id.home);
        favorite = (ImageView) findViewById(R.id.favorite);
        location = (ImageView) findViewById(R.id.location);
        user = (ImageView) findViewById(R.id.user);
        cart = (ImageView) findViewById(R.id.cart);
        exit = (ImageView) findViewById(R.id.exit);
        login_view = (View) findViewById(R.id.login_view);
        register_view = (View) findViewById(R.id.register_view);
        login = (TextView) findViewById(R.id.login);
        register = (TextView) findViewById(R.id.register);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerList = (ExpandableListView) findViewById(R.id.left_drawer);
        data_in_list();
        Drawer_Adapter adapter = new Drawer_Adapter(this,list_data_header,hashMap);
        mDrawerList.setAdapter(adapter);
        mDrawerList.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int i) {
                for (int m=0;m<4;m++){
                    if (m!=i) {
                        mDrawerList.collapseGroup(m);
                    }
                }
            }
        });
        menu_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mDrawerLayout.isDrawerOpen(GravityCompat.START)){
                    mDrawerLayout.closeDrawer(GravityCompat.START);
                }
                else {
                    mDrawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login.setTextColor(Color.parseColor("#47525e"));
                login_view.setBackgroundResource(R.color.darkgrey);
                register.setTextColor(Color.parseColor("#c0ccda"));
                register_view.setBackgroundResource(R.color.lightgrey);
                Fragment fragment_=new user();
                FragmentManager manager_=getSupportFragmentManager();
                FragmentTransaction transaction_=manager_.beginTransaction();
                transaction_.replace(R.id.fragment__,fragment_);
                transaction_.commit();
            }
        });
        local.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                local___();
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                register.setTextColor(Color.parseColor("#47525e"));
                register_view.setBackgroundResource(R.color.darkgrey);
                login.setTextColor(Color.parseColor("#c0ccda"));
                login_view.setBackgroundResource(R.color.lightgrey);
                Fragment fragment_=new Registration();
                FragmentManager manager_=getSupportFragmentManager();
                FragmentTransaction transaction_=manager_.beginTransaction();
                transaction_.replace(R.id.fragment__,fragment_);
                transaction_.commit();
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "My application name");
                    startActivity(Intent.createChooser(i, "choose one"));
                } catch(Exception e) {
                    //e.toString();
                }
            }
        });

        share.setVisibility(View.GONE);
        Fragment fragment_=new user();
        FragmentManager manager_=getSupportFragmentManager();
        FragmentTransaction transaction_=manager_.beginTransaction();
        transaction_.replace(R.id.fragment__,fragment_);
        transaction_.commit();


        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                display_dialog();
            }
        });
        favorite_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mDrawerLayout.closeDrawer(GravityCompat.START);
                share.setVisibility(View.GONE);
                home__.setTextColor(Color.parseColor("#757575"));
                favorite__.setTextColor(Color.parseColor("#E24D85"));
                location__.setTextColor(Color.parseColor("#757575"));
                user__.setTextColor(Color.parseColor("#757575"));
                cart__.setTextColor(Color.parseColor("#757575"));

                local.setVisibility(View.VISIBLE);
                favorite.setImageResource(R.mipmap.favorite);
                home.setImageResource(R.mipmap.home_);
                user.setImageResource(R.mipmap.user1_);
                location.setImageResource(R.mipmap.location_);
                cart.setImageResource(R.mipmap.cart_);
                layout_home.setVisibility(View.GONE);
                layout2.setVisibility(View.VISIBLE);
                Fragment fragment=new favorite();
                FragmentManager manager=getSupportFragmentManager();
                FragmentTransaction transaction=manager.beginTransaction();
                transaction.replace(R.id.fragment_,fragment);
                transaction.commit();
            }
        });


        location_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDrawerLayout.closeDrawer(GravityCompat.START);
                share.setVisibility(View.GONE);
                home__.setTextColor(Color.parseColor("#757575"));
                favorite__.setTextColor(Color.parseColor("#757575"));
                location__.setTextColor(Color.parseColor("#E24D85"));
                user__.setTextColor(Color.parseColor("#757575"));
                cart__.setTextColor(Color.parseColor("#757575"));

                local.setVisibility(View.VISIBLE);
                favorite.setImageResource(R.mipmap.favorite_);
                home.setImageResource(R.mipmap.home_);
                user.setImageResource(R.mipmap.user1_);
                location.setImageResource(R.mipmap.location);
                cart.setImageResource(R.mipmap.cart_);
                layout_user.setVisibility(View.GONE);
                layout_home.setVisibility(View.GONE);
                layout2.setVisibility(View.VISIBLE);
                Fragment fragment=new location();
                FragmentManager manager=getSupportFragmentManager();
                FragmentTransaction transaction=manager.beginTransaction();
                transaction.replace(R.id.fragment_,fragment);
                transaction.commit();
            }
        });

        user_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                local.setVisibility(View.GONE);
                mDrawerLayout.closeDrawer(GravityCompat.START);
                share.setVisibility(View.VISIBLE);
                home__.setTextColor(Color.parseColor("#757575"));
                favorite__.setTextColor(Color.parseColor("#757575"));
                location__.setTextColor(Color.parseColor("#757575"));
                user__.setTextColor(Color.parseColor("#E24D85"));
                cart__.setTextColor(Color.parseColor("#757575"));

                favorite.setImageResource(R.mipmap.favorite_);
                home.setImageResource(R.mipmap.home_);
                user.setImageResource(R.mipmap.user1);
                location.setImageResource(R.mipmap.location_);
                cart.setImageResource(R.mipmap.cart_);
                layout_home.setVisibility(View.GONE);
                layout2.setVisibility(View.GONE);
                layout_user.setVisibility(View.VISIBLE);
            }
        });
        cart_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout_user.setVisibility(View.GONE);
                mDrawerLayout.closeDrawer(GravityCompat.START);
                share.setVisibility(View.GONE);
                home__.setTextColor(Color.parseColor("#757575"));
                favorite__.setTextColor(Color.parseColor("#757575"));
                location__.setTextColor(Color.parseColor("#757575"));
                user__.setTextColor(Color.parseColor("#757575"));
                cart__.setTextColor(Color.parseColor("#E24D85"));

                local.setVisibility(View.VISIBLE);
                favorite.setImageResource(R.mipmap.favorite_);
                home.setImageResource(R.mipmap.home_);
                user.setImageResource(R.mipmap.user1_);
                location.setImageResource(R.mipmap.location_);
                cart.setImageResource(R.mipmap.cart);
                layout_home.setVisibility(View.GONE);
                layout2.setVisibility(View.VISIBLE);
                Fragment fragment=new cart();
                FragmentManager manager=getSupportFragmentManager();
                FragmentTransaction transaction=manager.beginTransaction();
                transaction.replace(R.id.fragment_,fragment);
                transaction.commit();
            }
        });
        home.setImageResource(R.mipmap.home);
        home_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                home_click();
            }
        });
        Fragment fragment=new home();
        FragmentManager manager=getSupportFragmentManager();
        FragmentTransaction transaction=manager.beginTransaction();
        transaction.replace(R.id.fragment,fragment);
        transaction.commit();
    }

    private void data_in_list() {
        list_data_header = new ArrayList<>();
        hashMap = new HashMap<>();
        list_data_header.add(0,"header");
        list_data_header.add(1,"بلد");
        list_data_header.add(2,"الفئة");
        list_data_header.add(3,"range");

        List<String> clist = new ArrayList<>();
        clist.add("بلد 1");
        clist.add("بلد 2");
        clist.add("بلد 3");

        List<String> category_list  = new ArrayList<>();
        category_list.add("الفئة 1");
        category_list.add("الفئة 2");
        category_list.add("الفئة 3");

        List<String> header = new ArrayList<>();

        hashMap.put(list_data_header.get(0),header);
        hashMap.put(list_data_header.get(1),clist);
        hashMap.put(list_data_header.get(2),category_list);
        hashMap.put(list_data_header.get(3),header);
    }

    @Override
    public void onStop(){
        super.onStop();
        Utils.is_home_fragment = false;
    }
    public static void home_click(){
        local.setVisibility(View.VISIBLE);
        share.setVisibility(View.GONE);
        home__.setTextColor(Color.parseColor("#E24D85"));
        favorite__.setTextColor(Color.parseColor("#757575"));
        location__.setTextColor(Color.parseColor("#757575"));
        user__.setTextColor(Color.parseColor("#757575"));
        cart__.setTextColor(Color.parseColor("#757575"));
        mDrawerLayout.closeDrawer(GravityCompat.START);
        favorite.setImageResource(R.mipmap.favorite_);
        home.setImageResource(R.mipmap.home);
        user.setImageResource(R.mipmap.user1_);
        location.setImageResource(R.mipmap.location_);
        cart.setImageResource(R.mipmap.cart_);
        layout_home.setVisibility(View.VISIBLE);
        layout_user.setVisibility(View.GONE);
        layout2.setVisibility(View.GONE);
    }
    @Override
    public void onPause(){
        super.onStop();
        Utils.is_home_fragment = false;
    }

    @Override
    public void onStart(){
        super.onStop();
        Utils.is_home_fragment = true;
    }

    @Override
    public void onResume(){
        super.onStop();
        Utils.is_home_fragment = true;
    }

    @Override
    public void onBackPressed() {
        display_dialog();
    }
    void display_dialog(){

        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        View dialog = getLayoutInflater().inflate(R.layout.back_pressed,null);

        TextView yes_ = (TextView) dialog.findViewById(R.id.yes_);
        TextView no__ = (TextView) dialog.findViewById(R.id.no__);

        builder.setView(dialog);

        final AlertDialog alertDialog = builder.create();
        no__.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
        yes_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences preferences = getSharedPreferences("user_id",MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                if (!preferences.getBoolean("remember",false)){
                    editor.clear();
                }
                editor.commit();
                finish();
            }
        });
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        alertDialog.show();
    }

    private void local___() {
        display_dialog__();
    }

    void display_dialog__(){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        View dialog = getLayoutInflater().inflate(R.layout.language_selection,null);
        final RadioButton arabic = (RadioButton) dialog.findViewById(R.id.arabic);
        final RadioButton english = (RadioButton) dialog.findViewById(R.id.english);
        SharedPreferences preferences = getSharedPreferences("lang", MODE_PRIVATE);
        if (preferences.getString("lang","").equals("ar")){
            arabic.setChecked(true);
            english.setChecked(false);
        }
        else
        {
            arabic.setChecked(false);
            english.setChecked(true);
        }

        builder.setView(dialog);
        final AlertDialog alertDialog = builder.create();
        arabic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                arabic.setChecked(true);
                english.setChecked(false);
                String languageToLoad = "de";
                Locale locale = new Locale(languageToLoad);
                Locale.setDefault(locale);

                Configuration config = new Configuration();
                config.locale = locale;
                getBaseContext().getResources().updateConfiguration(config,
                        getBaseContext().getResources().getDisplayMetrics());


                SharedPreferences preferences = getSharedPreferences("lang",MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("lang","ar");
                editor.commit();
                Intent intent = new Intent(MainActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        english.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                arabic.setChecked(false);
                english.setChecked(true);
                String languageToLoad = "en";
                Locale locale = new Locale(languageToLoad);
                Locale.setDefault(locale);
                Configuration config = new Configuration();
                config.locale = locale;
                getBaseContext().getResources().updateConfiguration(config,
                        getBaseContext().getResources().getDisplayMetrics());


                SharedPreferences preferences = getSharedPreferences("lang",MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("lang","en");
                editor.commit();
                Intent intent = new Intent(MainActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        //alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        alertDialog.show();
    }
}
