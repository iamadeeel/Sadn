package com.smartcoder.saden;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.nhaarman.listviewanimations.appearance.AnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.SwingRightInAnimationAdapter;
import com.smartcoder.saden.Adapters.Select_Category_Adapter;

public class Select_Category extends AppCompatActivity {

    TextView top_text;
    ListView list;
    public static Activity fa;
    Select_Category_Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select__category);

        fa = this;
        top_text = (TextView) findViewById(R.id.top_text);

        SharedPreferences preferences = getSharedPreferences("lang",MODE_PRIVATE);
        if (preferences.getString("lang","").equals("ar"))
        {
            top_text.setText(Utils.show_categories.getNameAr()+"");
        }
        else {

            top_text.setText(Utils.show_categories.getNameEn()+"");
        }
        list = (ListView) findViewById(R.id.list);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Utils.sub_category = Utils.show_categories.getSub_categories().get(i);
                Intent intent = new Intent(Select_Category.this,Detail.class);
                startActivity(intent);
            }
        });

        final ImageView finish  = (ImageView) findViewById(R.id.finish);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        adapter = new Select_Category_Adapter(Select_Category.this,Utils.show_categories.getSub_categories());
        AnimationAdapter mAnimAdapter = new SwingRightInAnimationAdapter(adapter);/*
        AnimationAdapter mAnimAdapter = new SwingBottomInAnimationAdapter(new SwingRightInAnimationAdapter(adapter));*/
        mAnimAdapter.setAbsListView(list);
        list.setAdapter(mAnimAdapter);

    }
}
