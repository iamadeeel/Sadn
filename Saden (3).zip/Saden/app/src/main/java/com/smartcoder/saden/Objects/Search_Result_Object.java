package com.smartcoder.saden.Objects;

/**
 * Created by Adeel on 10/07/2017.
 */

public class Search_Result_Object {
    String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
