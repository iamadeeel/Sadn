package com.smartcoder.saden;

import com.smartcoder.saden.Objects.Advertisement;
import com.smartcoder.saden.Objects.Categories;
import com.smartcoder.saden.Objects.Search_Result_Object;
import com.smartcoder.saden.Objects.Sub_Category;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Adeel on 10/07/2017.
 */

public class Utils {
    public static Boolean is_home_fragment = true;
    public static List<Categories> categories_list = new ArrayList<>();
    public static List<Categories> favorite_list = new ArrayList<>();
    public static Categories show_categories = new Categories();
    public static Sub_Category sub_category = new Sub_Category();
    public static List<Advertisement> ads = new ArrayList<>();
    public static Advertisement advertisement = new Advertisement();
    public static List<Sub_Category> search_list = new ArrayList<>();
}