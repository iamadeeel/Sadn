package com.smartcoder.saden.Fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.nhaarman.listviewanimations.appearance.AnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.SwingRightInAnimationAdapter;
import com.smartcoder.saden.Adapters.Cart_Adapter;
import com.smartcoder.saden.Objects.Cart_Object;
import com.smartcoder.saden.R;

import java.util.ArrayList;
import java.util.List;

public class cart extends Fragment {

    ListView listView;
    Cart_Adapter adapter;
    List<Cart_Object> list = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cart, container, false);
        listView = (ListView) view.findViewById(R.id.list_view);

/*        for (int i=0;i<10;i++){
            Cart_Object object = new Cart_Object();
            list.add(object);
        }
        adapter  = new Cart_Adapter(getActivity(),list);

        AnimationAdapter mAnimAdapter = new SwingRightInAnimationAdapter(adapter);*//*
        AnimationAdapter mAnimAdapter = new SwingBottomInAnimationAdapter(new SwingRightInAnimationAdapter(adapter));*//*
        mAnimAdapter.setAbsListView(listView);
        listView.setAdapter(mAnimAdapter);*/
        return view;
    }
}
