package com.smartcoder.saden.Adapters;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.smartcoder.saden.Objects.Favorite_Object;
import com.smartcoder.saden.Objects.Sub_Category;
import com.smartcoder.saden.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Adeel on 11/02/2017.
 */

public class Select_Category_Adapter extends BaseAdapter {

    private Activity activity;

    private LayoutInflater inflater;
    private java.util.List<Sub_Category> List=new ArrayList<Sub_Category>();

    public Select_Category_Adapter(Activity activity, java.util.List<Sub_Category> allist) {
        this.activity = activity;
        this.List = allist;
    }

    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int location) {
        return List.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = activity.getLayoutInflater();
        View  rowView = null;
        SharedPreferences preferences  =activity.getSharedPreferences("lang", Context.MODE_PRIVATE);
        if (preferences.getString("lang","").equals("ar")){
            rowView = inflater.inflate(R.layout.sub_category,null,true);
            TextView name = (TextView) rowView.findViewById(R.id.name);
            TextView phone = (TextView) rowView.findViewById(R.id.phone);
            TextView city = (TextView) rowView.findViewById(R.id.city);

            name.setText(List.get(position).getNameAr());
            phone.setText(List.get(position).getMobileNo());
            city.setText(List.get(position).getCityNameAr());

        }
        else {
            rowView = inflater.inflate(R.layout.sub_category_en,null,true);
            TextView name = (TextView) rowView.findViewById(R.id.name);
            TextView phone = (TextView) rowView.findViewById(R.id.phone);
            TextView city = (TextView) rowView.findViewById(R.id.city);

            name.setText(List.get(position).getNameEn());
            phone.setText(List.get(position).getMobileNo());
            city.setText(List.get(position).getCityNameEn());
        }

        return rowView;
    }
}
