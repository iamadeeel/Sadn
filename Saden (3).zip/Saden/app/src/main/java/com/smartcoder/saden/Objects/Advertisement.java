package com.smartcoder.saden.Objects;

/**
 * Created by Adeel on 11/15/2017.
 */

public class Advertisement {
    String AdvertisementID = "";
    String BeautyCenterID = "";
    String IsInternalAd = "";
    String ImageArID = "";
    String ImageEnID = "";
    String WebLinkAr = "";
    String WebLinkEn = "";
    String BeautyCenterNameAr = "";

    public String getAdvertisementID() {
        return AdvertisementID;
    }

    public void setAdvertisementID(String advertisementID) {
        AdvertisementID = advertisementID;
    }

    public String getBeautyCenterID() {
        return BeautyCenterID;
    }

    public void setBeautyCenterID(String beautyCenterID) {
        BeautyCenterID = beautyCenterID;
    }

    public String getIsInternalAd() {
        return IsInternalAd;
    }

    public void setIsInternalAd(String isInternalAd) {
        IsInternalAd = isInternalAd;
    }

    public String getImageArID() {
        return ImageArID;
    }

    public void setImageArID(String imageArID) {
        ImageArID = imageArID;
    }

    public String getImageEnID() {
        return ImageEnID;
    }

    public void setImageEnID(String imageEnID) {
        ImageEnID = imageEnID;
    }

    public String getWebLinkAr() {
        return WebLinkAr;
    }

    public void setWebLinkAr(String webLinkAr) {
        WebLinkAr = webLinkAr;
    }

    public String getWebLinkEn() {
        return WebLinkEn;
    }

    public void setWebLinkEn(String webLinkEn) {
        WebLinkEn = webLinkEn;
    }

    public String getBeautyCenterNameAr() {
        return BeautyCenterNameAr;
    }

    public void setBeautyCenterNameAr(String beautyCenterNameAr) {
        BeautyCenterNameAr = beautyCenterNameAr;
    }

    public String getBeautyCenterNameEn() {
        return BeautyCenterNameEn;
    }

    public void setBeautyCenterNameEn(String beautyCenterNameEn) {
        BeautyCenterNameEn = beautyCenterNameEn;
    }

    String BeautyCenterNameEn = "";
}
