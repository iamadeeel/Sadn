package com.smartcoder.saden.Objects;

import android.graphics.Bitmap;

import com.smartcoder.saden.Utils;

/**
 * Created by Adeel on 10/16/2017.
 */

public class Sub_Category {
    public String getBeautyCenterID() {
        return BeautyCenterID;
    }

    public void setBeautyCenterID(String beautyCenterID) {
        BeautyCenterID = beautyCenterID;
    }

    public String getNameEn() {
        return NameEn;
    }

    public void setNameEn(String nameEn) {
        NameEn = nameEn;
    }

    public String getNameAr() {
        return NameAr;
    }

    public void setNameAr(String nameAr) {
        NameAr = nameAr;
    }

    public String getDescriptionEn() {
        return DescriptionEn;
    }

    public void setDescriptionEn(String descriptionEn) {
        DescriptionEn = descriptionEn;
    }

    public String getDescriptionAr() {
        return DescriptionAr;
    }

    public void setDescriptionAr(String descriptionAr) {
        DescriptionAr = descriptionAr;
    }

    public String getImageArID() {
        return ImageArID;
    }

    public void setImageArID(String imageArID) {
        ImageArID = imageArID;
    }

    public String getImageEnID() {
        return ImageEnID;
    }

    public void setImageEnID(String imageEnID) {
        ImageEnID = imageEnID;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String mobileNo) {
        MobileNo = mobileNo;
    }

    public String getLandlineNo() {
        return LandlineNo;
    }

    public void setLandlineNo(String landlineNo) {
        LandlineNo = landlineNo;
    }

    public String getFaxNo() {
        return FaxNo;
    }

    public void setFaxNo(String faxNo) {
        FaxNo = faxNo;
    }

    public String getPOBox() {
        return POBox;
    }

    public void setPOBox(String POBox) {
        this.POBox = POBox;
    }

    public String getPostSymbol() {
        return PostSymbol;
    }

    public void setPostSymbol(String postSymbol) {
        PostSymbol = postSymbol;
    }

    public String getDistrictNameAr() {
        return DistrictNameAr;
    }

    public void setDistrictNameAr(String districtNameAr) {
        DistrictNameAr = districtNameAr;
    }

    public String getDistrictNameEn() {
        return DistrictNameEn;
    }

    public void setDistrictNameEn(String districtNameEn) {
        DistrictNameEn = districtNameEn;
    }

    public String getStreetNameAr() {
        return StreetNameAr;
    }

    public void setStreetNameAr(String streetNameAr) {
        StreetNameAr = streetNameAr;
    }

    public String getStreetNameEn() {
        return StreetNameEn;
    }

    public void setStreetNameEn(String streetNameEn) {
        StreetNameEn = streetNameEn;
    }

    public String getDetailedAddressAr() {
        return DetailedAddressAr;
    }

    public void setDetailedAddressAr(String detailedAddressAr) {
        DetailedAddressAr = detailedAddressAr;
    }

    public String getDetailedAddressEn() {
        return DetailedAddressEn;
    }

    public void setDetailedAddressEn(String detailedAddressEn) {
        DetailedAddressEn = detailedAddressEn;
    }

    public String getLatValue() {
        return LatValue;
    }

    public void setLatValue(String latValue) {
        LatValue = latValue;
    }

    public String getLonValue() {
        return LonValue;
    }

    public void setLonValue(String lonValue) {
        LonValue = lonValue;
    }

    public String getWorkingHoursStart() {
        return WorkingHoursStart;
    }

    public void setWorkingHoursStart(String workingHoursStart) {
        WorkingHoursStart = workingHoursStart;
    }

    public String getWorkingHoursEnd() {
        return WorkingHoursEnd;
    }

    public void setWorkingHoursEnd(String workingHoursEnd) {
        WorkingHoursEnd = workingHoursEnd;
    }

    public String getFacebookAccount() {
        return FacebookAccount;
    }

    public void setFacebookAccount(String facebookAccount) {
        FacebookAccount = facebookAccount;
    }

    public String getInstagramAccount() {
        return InstagramAccount;
    }

    public void setInstagramAccount(String instagramAccount) {
        InstagramAccount = instagramAccount;
    }

    public String getTwitterAccount() {
        return TwitterAccount;
    }

    public void setTwitterAccount(String twitterAccount) {
        TwitterAccount = twitterAccount;
    }

    public String getYoutubeAccount() {
        return YoutubeAccount;
    }

    public void setYoutubeAccount(String youtubeAccount) {
        YoutubeAccount = youtubeAccount;
    }

    public String getSnapchatAccount() {
        return SnapchatAccount;
    }

    public void setSnapchatAccount(String snapchatAccount) {
        SnapchatAccount = snapchatAccount;
    }

    public String getNotes() {
        return Notes;
    }

    public void setNotes(String notes) {
        Notes = notes;
    }

    public String getCityNameAr() {
        return CityNameAr;
    }

    public void setCityNameAr(String cityNameAr) {
        CityNameAr = cityNameAr;
    }

    public String getCityNameEn() {
        return CityNameEn;
    }

    public void setCityNameEn(String cityNameEn) {
        CityNameEn = cityNameEn;
    }

    public String getBeautyCenterImagesList() {
        return BeautyCenterImagesList;
    }

    public void setBeautyCenterImagesList(String beautyCenterImagesList) {
        BeautyCenterImagesList = beautyCenterImagesList;
    }

    public Bitmap getLoad_image_Bitmap() {
        return Load_image_Bitmap;
    }

    public void setLoad_image_Bitmap(Bitmap load_image_Bitmap) {
        Load_image_Bitmap = load_image_Bitmap;
    }

    String BeautyCenterID = "";
    String NameEn = "";
    String NameAr = "";
    String DescriptionEn = "";
    String DescriptionAr = "";
    String  ImageArID= "";
    String  ImageEnID="";
    String  MobileNo= "";
    String  LandlineNo="";
    String  FaxNo= "";
    String  POBox="";
    String  PostSymbol= "";
    String  DistrictNameAr="";
    String  DistrictNameEn= "";
    String  StreetNameAr="";
    String  StreetNameEn= "";
    String  DetailedAddressAr="";
    String  DetailedAddressEn="";
    String  LatValue= "";
    String  LonValue= "";
    String  WorkingHoursStart="";
    String  WorkingHoursEnd="";
    String  FacebookAccount= "";
    String  InstagramAccount= "";
    String  TwitterAccount="";
    String  YoutubeAccount="";
    String  SnapchatAccount= "";
    String  Notes= "";
    String  CityNameAr="";
    String  CityNameEn="";
    String  BeautyCenterImagesList= "";
    Bitmap Load_image_Bitmap = null;

}
