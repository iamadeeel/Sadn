package com.smartcoder.saden;

import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.smartcoder.saden.Class.CountryPickerListener;
import com.smartcoder.saden.Fragments.CountryPicker;
import com.smartcoder.saden.Fragments.Registration;
import com.smartcoder.saden.Fragments.cart;
import com.smartcoder.saden.Fragments.favorite;
import com.smartcoder.saden.Fragments.home;
import com.smartcoder.saden.Fragments.location;
import com.smartcoder.saden.Fragments.user;

import org.json.JSONException;

public class Navigation extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    ImageView home,favorite,more,location,cart,user,exit;
    RelativeLayout home_,favorite_,location_,cart_,user_;
    TextView home__,favorite__,location__,cart__,user__;
    Fragment fragment,fragment_;
    RelativeLayout layout_home,layout2,layout_user;
    View login_view,register_view;
    TextView login,register;
    ImageView share;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);



        share = (ImageView) findViewById(R.id.share);
        home__ = (TextView) findViewById(R.id.home__);
        favorite__ = (TextView) findViewById(R.id.favorite__);
        location__ = (TextView) findViewById(R.id.location__);
        cart__ = (TextView) findViewById(R.id.cart__);
        user__ = (TextView) findViewById(R.id.user__);
        home_ = (RelativeLayout) findViewById(R.id.home_rel);
        favorite_ = (RelativeLayout) findViewById(R.id.favorite_rel);
        location_ = (RelativeLayout) findViewById(R.id.location_rel);
        cart_ = (RelativeLayout) findViewById(R.id.cart_rel);
        user_ = (RelativeLayout) findViewById(R.id.user_rel);
        layout_user = (RelativeLayout) findViewById(R.id.rel_user);
        layout_home = (RelativeLayout) findViewById(R.id.rel);
        layout2 = (RelativeLayout) findViewById(R.id.rel2);
        home = (ImageView) findViewById(R.id.home);
        favorite = (ImageView) findViewById(R.id.favorite);
        /*more = (ImageView) findViewById(R.id.dots);*/
        location = (ImageView) findViewById(R.id.location);
        user = (ImageView) findViewById(R.id.user);
        cart = (ImageView) findViewById(R.id.cart);
        exit = (ImageView) findViewById(R.id.exit);
        login_view = (View) findViewById(R.id.login_view);
        register_view = (View) findViewById(R.id.register_view);
        login = (TextView) findViewById(R.id.login);
        register = (TextView) findViewById(R.id.register);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login.setTextColor(Color.parseColor("#47525e"));
                login_view.setBackgroundResource(R.color.darkgrey);
                register.setTextColor(Color.parseColor("#c0ccda"));
                register_view.setBackgroundResource(R.color.lightgrey);
                Fragment fragment_=new user();
                FragmentManager manager_=getSupportFragmentManager();
                FragmentTransaction transaction_=manager_.beginTransaction();
                transaction_.replace(R.id.fragment__,fragment_);
                transaction_.commit();
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                register.setTextColor(Color.parseColor("#47525e"));
                register_view.setBackgroundResource(R.color.darkgrey);
                login.setTextColor(Color.parseColor("#c0ccda"));
                login_view.setBackgroundResource(R.color.lightgrey);
                Fragment fragment_=new Registration();
                FragmentManager manager_=getSupportFragmentManager();
                FragmentTransaction transaction_=manager_.beginTransaction();
                transaction_.replace(R.id.fragment__,fragment_);
                transaction_.commit();
            }
        });

        share.setVisibility(View.GONE);
        Fragment fragment_=new user();
        FragmentManager manager_=getSupportFragmentManager();
        FragmentTransaction transaction_=manager_.beginTransaction();
        transaction_.replace(R.id.fragment__,fragment_);
        transaction_.commit();


        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Utils.is_home_fragment = false;
                finish();
            }
        });
        favorite_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                share.setVisibility(View.GONE);
                home__.setTextColor(Color.parseColor("#c0ccda"));
                favorite__.setTextColor(Color.parseColor("#47525e"));
                location__.setTextColor(Color.parseColor("#c0ccda"));
                user__.setTextColor(Color.parseColor("#c0ccda"));
                cart__.setTextColor(Color.parseColor("#c0ccda"));

                favorite.setImageResource(R.mipmap.favorite);
                home.setImageResource(R.mipmap.home_);
                user.setImageResource(R.mipmap.user1_);
                location.setImageResource(R.mipmap.location_);
                cart.setImageResource(R.mipmap.cart_);
                layout_home.setVisibility(View.GONE);
                layout2.setVisibility(View.VISIBLE);
                Fragment fragment=new favorite();
                FragmentManager manager=getSupportFragmentManager();
                FragmentTransaction transaction=manager.beginTransaction();
                transaction.replace(R.id.fragment_,fragment);
                transaction.commit();
            }
        });

/*        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout1.setVisibility(View.GONE);
                layout2.setVisibility(View.VISIBLE);
                Fragment fragment=new more();
                FragmentManager manager=getSupportFragmentManager();
                FragmentTransaction transaction=manager.beginTransaction();
                transaction.replace(R.id.fragment_,fragment);
                transaction.commit();
            }
        });*/

        location_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                share.setVisibility(View.GONE);
                home__.setTextColor(Color.parseColor("#c0ccda"));
                favorite__.setTextColor(Color.parseColor("#c0ccda"));
                location__.setTextColor(Color.parseColor("#47525e"));
                user__.setTextColor(Color.parseColor("#c0ccda"));
                cart__.setTextColor(Color.parseColor("#c0ccda"));

                favorite.setImageResource(R.mipmap.favorite_);
                home.setImageResource(R.mipmap.home_);
                user.setImageResource(R.mipmap.user1_);
                location.setImageResource(R.mipmap.location);
                cart.setImageResource(R.mipmap.cart_);
                layout_user.setVisibility(View.GONE);
                layout_home.setVisibility(View.GONE);
                layout2.setVisibility(View.VISIBLE);
                Fragment fragment=new location();
                FragmentManager manager=getSupportFragmentManager();
                FragmentTransaction transaction=manager.beginTransaction();
                transaction.replace(R.id.fragment_,fragment);
                transaction.commit();
            }
        });

        user_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                share.setVisibility(View.VISIBLE);
                home__.setTextColor(Color.parseColor("#c0ccda"));
                favorite__.setTextColor(Color.parseColor("#c0ccda"));
                location__.setTextColor(Color.parseColor("#c0ccda"));
                user__.setTextColor(Color.parseColor("#47525e"));
                cart__.setTextColor(Color.parseColor("#c0ccda"));

                favorite.setImageResource(R.mipmap.favorite_);
                home.setImageResource(R.mipmap.home_);
                user.setImageResource(R.mipmap.user1);
                location.setImageResource(R.mipmap.location_);
                cart.setImageResource(R.mipmap.cart_);
                layout_home.setVisibility(View.GONE);
                layout2.setVisibility(View.GONE);
                layout_user.setVisibility(View.VISIBLE);
            }
        });
        cart_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout_user.setVisibility(View.GONE);

                share.setVisibility(View.GONE);
                home__.setTextColor(Color.parseColor("#c0ccda"));
                favorite__.setTextColor(Color.parseColor("#c0ccda"));
                location__.setTextColor(Color.parseColor("#c0ccda"));
                user__.setTextColor(Color.parseColor("#c0ccda"));
                cart__.setTextColor(Color.parseColor("#47525e"));

                favorite.setImageResource(R.mipmap.favorite_);
                home.setImageResource(R.mipmap.home_);
                user.setImageResource(R.mipmap.user1_);
                location.setImageResource(R.mipmap.location_);
                cart.setImageResource(R.mipmap.cart);
                layout_home.setVisibility(View.GONE);
                layout2.setVisibility(View.VISIBLE);
                Fragment fragment=new cart();
                FragmentManager manager=getSupportFragmentManager();
                FragmentTransaction transaction=manager.beginTransaction();
                transaction.replace(R.id.fragment_,fragment);
                transaction.commit();
            }
        });
        home.setImageResource(R.mipmap.home);
        home_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                share.setVisibility(View.GONE);
                home__.setTextColor(Color.parseColor("#47525e"));
                favorite__.setTextColor(Color.parseColor("#c0ccda"));
                location__.setTextColor(Color.parseColor("#c0ccda"));
                user__.setTextColor(Color.parseColor("#c0ccda"));
                cart__.setTextColor(Color.parseColor("#c0ccda"));

                favorite.setImageResource(R.mipmap.favorite_);
                home.setImageResource(R.mipmap.home);
                user.setImageResource(R.mipmap.user1_);
                location.setImageResource(R.mipmap.location_);
                cart.setImageResource(R.mipmap.cart_);
                layout_home.setVisibility(View.VISIBLE);
                layout_user.setVisibility(View.GONE);
                layout2.setVisibility(View.GONE);
            }
        });
        Fragment fragment=new home();
        FragmentManager manager=getSupportFragmentManager();
        FragmentTransaction transaction=manager.beginTransaction();
        transaction.replace(R.id.fragment,fragment);
        transaction.commit();



    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.navigation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        /*if (id == R.id.action_settings) {
            return true;
        }*/

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
            final CountryPicker picker = CountryPicker.newInstance("Select Country");
            picker.show(getSupportFragmentManager(), "COUNTRY_PICKER");
            picker.setListener(new CountryPickerListener() {

                @Override
                public void onSelectCountry(String name, String code) {

                    picker.dismiss();
                }
            });
        } else if (id == R.id.category) {
            // Handle the camera action
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onStop(){
        super.onStop();
        Utils.is_home_fragment = false;
    }

    @Override
    public void onPause(){
        super.onStop();
        Utils.is_home_fragment = false;
    }

    @Override
    public void onStart(){
        super.onStop();
        Utils.is_home_fragment = true;
    }

    @Override
    public void onResume(){
        super.onStop();
        Utils.is_home_fragment = true;
    }
}
