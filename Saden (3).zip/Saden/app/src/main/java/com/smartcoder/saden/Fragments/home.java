package com.smartcoder.saden.Fragments;

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.nhaarman.listviewanimations.appearance.AnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.AlphaInAnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.SwingBottomInAnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.SwingRightInAnimationAdapter;
import com.smartcoder.saden.Adapters.Home_List_Adapter;
import com.smartcoder.saden.Adapters.Search_Result_Adapter;
import com.smartcoder.saden.Adapters.TransformerAdapter;
import com.smartcoder.saden.Adapters.ViewPagerAdapter;
import com.smartcoder.saden.Class.MySingleTon;
import com.smartcoder.saden.Detail;
import com.smartcoder.saden.Objects.Categories;
import com.smartcoder.saden.Objects.Search_Result_Object;
import com.smartcoder.saden.Objects.Sub_Category;
import com.smartcoder.saden.R;
import com.smartcoder.saden.Select_Category;
import com.smartcoder.saden.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


public class home extends Fragment {
    ImageView [] categories = new ImageView[6];
    ListView search_result_list;
     List<Search_Result_Object> search_result = new ArrayList<Search_Result_Object>();

    ViewPager viewPager;
    LinearLayout sliderDotspanel;
    private int dotscount;
    private ImageView[] dots;

    ScrollView scroll_view;

    ListView home_list;
    Home_List_Adapter adapter;
    EditText search__;
    ImageView search;
    //List<Categories> home_objects_list = new ArrayList<>();

    private SliderLayout mDemoSlider;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view= inflater.inflate(R.layout.fragment_home, container, false);
        search__ = (EditText) view.findViewById(R.id.search__);
        search = (ImageView) view.findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (search__.getText().toString().isEmpty()){
                    Toast.makeText(getActivity(),R.string.search_field_is_empty,Toast.LENGTH_SHORT).show();
                }
                else {
                    ext(search__.getText().toString());
                }
            }
        });

        search__.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    if (search__.getText().toString().isEmpty()){
                        Toast.makeText(getActivity(),R.string.search_field_is_empty,Toast.LENGTH_SHORT).show();
                    }
                    else {
                        ext(search__.getText().toString());
                    }
                    return true;
                }
                return false;
            }
        });

        SharedPreferences preferences = getActivity().getSharedPreferences("lang",Context.MODE_PRIVATE);
        if (preferences.getString("lang","ar").equals("ar")){
            search__.setGravity(Gravity.END);
        }
        else {
            search__.setGravity(Gravity.START);
        }
        home_list = (ListView) view.findViewById(R.id.home_list);
        home_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Utils.show_categories = Utils.categories_list.get(i);
                Intent intent = new Intent(getActivity(), Select_Category.class);
                startActivity(intent);
            }
        });

        adapter = new Home_List_Adapter(getActivity(),Utils.categories_list);
        home_list.setAdapter(adapter);
        return view;
        }


    void ext(final String beautycenter_id) {
        {

            //showProgressDialog();
            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://madarnets.com/WS/SadnWSAndroid.asmx/GetBeautyCenterByID", new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {

                    //hideProgressDialog();
                    Log.e("JSON Response", s);


                    List<Sub_Category> search_list = new ArrayList<>();
                    try {
                        JSONArray array = new JSONArray(s);
                        for (int i=0;i<array.length();i++) {
                            JSONObject object = array.getJSONObject(i);
                            Sub_Category item = new Sub_Category();
                            item.setBeautyCenterID(object.getString("BeautyCenterID"));
                            item.setNameEn(object.getString("NameEn"));
                            item.setNameAr(object.getString("NameAr"));
                            item.setCityNameAr(object.getString("CityNameAr"));
                            item.setCityNameEn(object.getString("CityNameEn"));
                            item.setMobileNo(object.getString("MobileNo"));
                            item.setLandlineNo(object.getString("LandlineNo"));
                            item.setFaxNo(object.getString("FaxNo"));
                            item.setPOBox(object.getString("POBox"));
                            item.setPostSymbol(object.getString("PostSymbol"));
                            item.setStreetNameAr(object.getString("StreetNameAr"));
                            item.setStreetNameEn(object.getString("StreetNameEn"));
                            item.setDetailedAddressAr(object.getString("DetailedAddressAr"));
                            item.setDetailedAddressEn(object.getString("DetailedAddressEn"));
                            item.setLatValue(object.getString("LatValue"));
                            item.setLonValue(object.getString("LonValue"));
                            item.setWorkingHoursStart(object.getString("WorkingHoursStart"));
                            item.setWorkingHoursEnd(object.getString("WorkingHoursEnd"));
                            item.setFacebookAccount(object.getString("FacebookAccount"));
                            item.setInstagramAccount(object.getString("InstagramAccount"));
                            item.setTwitterAccount(object.getString("TwitterAccount"));
                            item.setYoutubeAccount(object.getString("YoutubeAccount"));
                            item.setSnapchatAccount(object.getString("SnapchatAccount"));
                            item.setNotes(object.getString("Notes"));
                            item.setBeautyCenterImagesList(object.getString("BeautyCenterImagesList"));
                            search_list.add(item);
                        }
                        Categories categories = new Categories();
                        SharedPreferences preferences = getActivity().getSharedPreferences("lang",Context.MODE_PRIVATE);
                        if (preferences.getString("lang","").equals("ar")){

                            categories.setNameAr("نتيجة البحث");
                        }
                        else {
                            categories.setNameEn("Search Result");
                        }
                        categories.setSub_categories(search_list);

                        Utils.show_categories = categories;
                        Intent intent = new Intent(getActivity(), Select_Category.class);
                        startActivity(intent);

                    } catch (JSONException e) {

                    }





                    /*if (s.equals("-1")){
                        Toast.makeText(getActivity(),R.string.already_added_favorite,Toast.LENGTH_SHORT).show();
                        //favorite___.setImageResource(R.mipmap.image_1_);
                    }
                    else if (s.equals("-2")){
                        Toast.makeText(getActivity(),R.string.unknown_error,Toast.LENGTH_SHORT).show();
                    }
                    else {
                        //favorite___.setImageResource(R.mipmap.image_1_);
                        //added to favorite

                    }*/

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {

                    //loading.dismiss();
                    Log.e("JSON Error", volleyError.toString());
                    Toast.makeText(getActivity(), "Error:" + volleyError.toString(), Toast.LENGTH_LONG).show();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("KEY","qsefthuko!@#456&*(PLIJYGRDWA");
                    parms.put("beautyCenterID", beautycenter_id );
                    return parms;
                }
            };

            stringRequest.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 10000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 10000;
                }

                @Override
                public void retry(VolleyError volleyError) throws VolleyError {

                }
            });
            MySingleTon.getInstance(getActivity()).addToRequestQueue(stringRequest);
        }
    }
    }

