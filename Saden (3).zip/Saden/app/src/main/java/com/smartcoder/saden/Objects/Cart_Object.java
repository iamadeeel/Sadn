package com.smartcoder.saden.Objects;

/**
 * Created by Adeel on 10/10/2017.
 */

public class Cart_Object {
    String profile_image_url;
    String logo_url;

    public String getProfile_image_url() {
        return profile_image_url;
    }

    public void setProfile_image_url(String profile_image_url) {
        this.profile_image_url = profile_image_url;
    }

    public String getLogo_url() {
        return logo_url;
    }

    public void setLogo_url(String logo_url) {
        this.logo_url = logo_url;
    }
}
