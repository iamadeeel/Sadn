package com.smartcoder.saden.Objects;

/**
 * Created by Adeel on 10/10/2017.
 */

public class Favorite_Object {

}
