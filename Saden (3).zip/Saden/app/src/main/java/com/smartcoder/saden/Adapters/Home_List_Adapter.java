package com.smartcoder.saden.Adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import com.smartcoder.saden.Detail;
import com.smartcoder.saden.Objects.Categories;
import com.smartcoder.saden.Objects.Sub_Category;
import com.smartcoder.saden.R;
import com.smartcoder.saden.Select_Category;
import com.smartcoder.saden.Utils;
import com.squareup.picasso.Picasso;

import org.xml.sax.Parser;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;

/**
 * Created by Adeel on 10/16/2017.
 */

public class Home_List_Adapter extends BaseAdapter {

    private LayoutInflater inflater;
    private java.util.List<Categories> List=new ArrayList<Categories>();
    private Activity activity;
    public Home_List_Adapter(Activity activity, java.util.List<Categories> allist) {
        this.activity = activity;
        this.List = allist;
    }

    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int location) {
        return List.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = activity.getLayoutInflater();
        View rowView = null;
        final SliderLayout mDemoSlider;
        if (List.get(position).getListitem().equals("slider")) {
            rowView = inflater.inflate(R.layout.slider, null, true);
            mDemoSlider = (SliderLayout) rowView.findViewById(R.id.slider);
            HashMap<String, String> url_maps = new HashMap<String, String>();

            final SharedPreferences preferences = activity.getSharedPreferences("lang",Context.MODE_PRIVATE);
            if (preferences.getString("lang","").equals("ar")) {
                for (int i = 0; i < Utils.ads.size(); i++) {
                    if (!Utils.ads.get(i).getBeautyCenterNameAr().isEmpty() && !Utils.ads.get(i).getImageArID().isEmpty())
                        url_maps.put(Utils.ads.get(i).getBeautyCenterNameAr(), Utils.ads.get(i).getImageArID());
                }
            }
            else{
                for (int i = 0; i < Utils.ads.size(); i++) {
                    if (!Utils.ads.get(i).getBeautyCenterNameEn().isEmpty() && !Utils.ads.get(i).getImageEnID().isEmpty())
                        url_maps.put(Utils.ads.get(i).getBeautyCenterNameEn(), Utils.ads.get(i).getImageEnID());
                }
            }

            for (String name : url_maps.keySet()) {
                TextSliderView textSliderView = new TextSliderView(activity);
                String  image= url_maps.get(name);
                if (image.isEmpty()){
                    image = "abc";
                }
                final String finalImage = image;
                textSliderView
                            .description(name)
                            .image(image)
                            .setScaleType(BaseSliderView.ScaleType.Fit)
                            .setOnSliderClickListener(new BaseSliderView.OnSliderClickListener() {
                                @Override
                                public void onSliderClick(BaseSliderView slider) {
                                    //SharedPreferences preferences1 = activity.getSharedPreferences("lang", Context.MODE_PRIVATE);
                                    if (preferences.getString("lang","").equals("ar")){
                                        for (int i=0;i<Utils.ads.size();i++){
                                            if (Utils.ads.get(i).getImageArID()== finalImage){
                                                Utils.advertisement = Utils.ads.get(i);
                                                Utils.sub_category = new Sub_Category();
                                                Utils.sub_category.setNameAr(Utils.advertisement.getBeautyCenterNameAr());
                                                //Utils.sub_category.setBeautyCenterID(Utils.advertisement.getBeautyCenterID());
                                                Utils.sub_category.setNameEn(Utils.advertisement.getBeautyCenterNameEn());

                                                Intent intent = new Intent(activity, Detail.class);
                                                activity.startActivity(intent);

                                            break;
                                            }
                                        }
                                    }
                                    else {
                                        for (int i=0;i<Utils.ads.size();i++){
                                            if (Utils.ads.get(i).getImageEnID()== finalImage){
                                                Utils.advertisement = Utils.ads.get(i);
                                                Utils.sub_category = new Sub_Category();
                                                Utils.sub_category.setNameAr(Utils.advertisement.getBeautyCenterNameAr());
                                                //Utils.sub_category.setBeautyCenterID(Utils.advertisement.getBeautyCenterID());
                                                Utils.sub_category.setNameEn(Utils.advertisement.getBeautyCenterNameEn());

                                                Intent intent = new Intent(activity, Detail.class);
                                                activity.startActivity(intent);

                                                break;
                                            }
                                        }
                                    }
                                    //Toast.makeText(activity, "text_slider" + slider, Toast.LENGTH_SHORT).show();
                                }
                            });
                    //add your extra information
                    textSliderView.bundle(new Bundle());
                    textSliderView.getBundle()
                            .putString("extra", name);

                    mDemoSlider.addSlider(textSliderView);
            }
            mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Accordion);
            mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
            mDemoSlider.setCustomAnimation(new DescriptionAnimation());
            mDemoSlider.setDuration(4000);
            mDemoSlider.addOnPageChangeListener(new ViewPagerEx.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    //Toast.makeText(activity,"page selected"+position,Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
        }
        else {

            SharedPreferences preferences = activity.getSharedPreferences("lang", Context.MODE_PRIVATE);
            if (preferences.getString("lang","ar").equals("ar")){
                rowView = inflater.inflate(R.layout.home_list_ar, null, true);
                ImageView view = rowView.findViewById(R.id.image2);
                TextView text = rowView.findViewById(R.id.text);
                TextView description = rowView.findViewById(R.id.description);
                text.setText(List.get(position).getNameAr());
                description.setText(List.get(position).getDescriptionAr());
                if (List.get(position).getImageArID()!=null&&List.get(position).getImageArID()!="")
                {
                    Picasso.with(activity).load(List.get(position).getImageArID()).into(view);
                }
            }
            else {
                rowView = inflater.inflate(R.layout.grid_list_item, null, true);
                ImageView view = rowView.findViewById(R.id.image2);
                TextView text = rowView.findViewById(R.id.text);
                TextView description = rowView.findViewById(R.id.description);
                text.setText(List.get(position).getNameEn());
                description.setText(List.get(position).getDescriptionEn());
                if (List.get(position).getImageEnID()!=null&&List.get(position).getImageEnID()!="")
                {
                    Picasso.with(activity).load(List.get(position).getImageEnID()).into(view);
                }

            }

        }
        return rowView;
    }
}
