package com.smartcoder.saden.Adapters;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.vision.text.Text;
import com.smartcoder.saden.Class.MySingleTon;
import com.smartcoder.saden.Objects.Favorite_Object;
import com.smartcoder.saden.Objects.Search_Result_Object;
import com.smartcoder.saden.Objects.Sub_Category;
import com.smartcoder.saden.R;
import com.smartcoder.saden.Utils;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Adeel on 10/10/2017.
 */

public class favorite_Adapter extends BaseAdapter {

    private Activity activity;

    private LayoutInflater inflater;
    private java.util.List<Sub_Category> List=new ArrayList<Sub_Category>();

    public favorite_Adapter(Activity activity, java.util.List<Sub_Category> allist) {
        this.activity = activity;
        this.List = allist;
    }

    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int location) {
        return List.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = activity.getLayoutInflater();

        View rowView = null;
        SharedPreferences sharedPreferences = activity.getSharedPreferences("lang",Context.MODE_PRIVATE);
        if (sharedPreferences.getString("lang","").equals("ar")){

            rowView = inflater.inflate(R.layout.favorite_row_view,null,true);
            // ImageView logo = (ImageView) rowView.findViewById(R.id.logo);
            TextView name__  = (TextView) rowView.findViewById(R.id.name);
            TextView phone = (TextView) rowView.findViewById(R.id.phone);
            TextView city = (TextView) rowView.findViewById(R.id.city);
            ImageView remove_favorite = (ImageView) rowView.findViewById(R.id.remove_favorite);
            remove_favorite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences preferences= activity.getSharedPreferences("user_id",Context.MODE_PRIVATE);
                    if (!preferences.getString("user_id","-1").equals("-1"))
                        ext(preferences.getString("user_id","-1"), Utils.sub_category.getBeautyCenterID(),position);
                }
            });
            name__.setText(List.get(position).getNameAr());
            phone.setText(List.get(position).getMobileNo());
            city.setText(List.get(position).getCityNameAr());
        }
        else {
            rowView = inflater.inflate(R.layout.favorite_en,null,true);
            // ImageView logo = (ImageView) rowView.findViewById(R.id.logo);
            TextView name__  = (TextView) rowView.findViewById(R.id.name);
            TextView phone = (TextView) rowView.findViewById(R.id.phone);
            TextView city = (TextView) rowView.findViewById(R.id.city);
            ImageView remove_favorite = (ImageView) rowView.findViewById(R.id.remove_favorite);
            remove_favorite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences preferences= activity.getSharedPreferences("user_id",Context.MODE_PRIVATE);
                    if (!preferences.getString("user_id","-1").equals("-1"))
                        ext(preferences.getString("user_id","-1"), Utils.sub_category.getBeautyCenterID(),position);
                }
            });

            name__.setText(List.get(position).getNameEn());
            phone.setText(List.get(position).getMobileNo());
            city.setText(List.get(position).getCityNameEn());

        }

        /*if (!List.get(position).getImageEnID().isEmpty())
        Picasso.with(activity).load(List.get(position).getImageEnID()).into(logo);
        else if (!List.get(position).getImageEnID().isEmpty())
            Picasso.with(activity).load(List.get(position).getImageArID()).into(logo);
*/
        return rowView;
    }

    void ext(final String user_id, final String product_id, final int k) {
        {

            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://madarnets.com/WS/SadnWSAndroid.asmx/DeleteCustomerFavorite", new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {

                    //dialog.dismiss();
                    Log.e("JSON Response", s);
                    if (s.equals("-1")){
                        Toast.makeText(activity,R.string.no_rec_found,Toast.LENGTH_SHORT).show();
                    }
                    else if (s.equals("-2")){
                        Toast.makeText(activity,R.string.unknown_error,Toast.LENGTH_SHORT).show();
                    }
                    else if (s.equals("0")){
                        List.remove(k);
                        notifyDataSetChanged();
                    }


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {

                    //loading.dismiss();
                    Log.e("JSON Error", volleyError.toString());
                    Toast.makeText(activity, "Error:" + volleyError.toString(), Toast.LENGTH_LONG).show();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("KEY","qsefthuko!@#456&*(PLIJYGRDWA");
                    parms.put("customerID", user_id + "");
                    parms.put("beautyCenterID", product_id + "");
                    return parms;
                }
            };

            stringRequest.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 10000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 10000;
                }

                @Override
                public void retry(VolleyError volleyError) throws VolleyError {

                }
            });
            MySingleTon.getInstance(activity).addToRequestQueue(stringRequest);
        }
    }
}
