package com.smartcoder.saden.Adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.smartcoder.saden.Objects.Search_Result_Object;
import com.smartcoder.saden.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Adeel on 10/07/2017.
 */

public class Search_Result_Adapter extends BaseAdapter {
    private Activity activity;

    private LayoutInflater inflater;
    private java.util.List<Search_Result_Object> List=new ArrayList<Search_Result_Object>();

    public Search_Result_Adapter(Activity activity, java.util.List<Search_Result_Object> allist) {
        this.activity = activity;
        this.List = allist;
    }

    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int location) {
        return List.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = activity.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.search_result_single_view,null,true);
        TextView textView = (TextView) rowView.findViewById(R.id.text___);
        textView.setText(List.get(position).getResult());

        return rowView;
    }
}
