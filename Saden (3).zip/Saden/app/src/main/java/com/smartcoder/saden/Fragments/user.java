package com.smartcoder.saden.Fragments;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.smartcoder.saden.Class.MySingleTon;
import com.smartcoder.saden.Detail;
import com.smartcoder.saden.Forget_Password;
import com.smartcoder.saden.MainActivity;
import com.smartcoder.saden.R;
import com.smartcoder.saden.Select_Category;
import com.smartcoder.saden.Sign_up;

import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class user extends Fragment {

    ImageView password_view;
    EditText textpassword,email___;
    TextView forgot_password;
    //ProgressDialog dialog = new ProgressDialog(getActivity());
    Boolean isChecked = false;
    private ProgressDialog mProgressDialog;
    CheckBox rememberme;
    TextView login;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view =inflater.inflate(R.layout.fragment_user, container, false);


        rememberme = (CheckBox) view.findViewById(R.id.rememberme);
        email___ = (EditText) view.findViewById(R.id.email___);
        login = (TextView) view.findViewById(R.id.login);
        forgot_password = (TextView) view.findViewById(R.id.forgot_password);
        password_view = (ImageView) view.findViewById(R.id.password_view);
        textpassword = (EditText) view.findViewById(R.id.textpassword);

        SharedPreferences preferences = getActivity().getSharedPreferences("lang", Context.MODE_PRIVATE);
        if (preferences.getString("lang","").equals("ar")){
            email___.setGravity(Gravity.END);
            textpassword.setGravity(Gravity.END);
        }
        forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Forget_Password.class);
                startActivity(intent);
            }
        });
        password_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!isChecked) {
                    textpassword.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    isChecked = true;
                } else {
                    textpassword.setInputType(129);
                    isChecked = false;
                }
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (email___.getText().toString().isEmpty()){
                    Toast.makeText(getActivity(),R.string.empty_email,Toast.LENGTH_SHORT).show();
                }
                else if (textpassword.getText().toString().isEmpty()){
                    Toast.makeText(getActivity(),R.string.empty_password,Toast.LENGTH_SHORT).show();
                }
                else if (textpassword.getText().toString().length()<6){
                    Toast.makeText(getActivity(),R.string.password_must_be_6,Toast.LENGTH_SHORT).show();
                }
                else {
                    ext(email___.getText().toString(),textpassword.getText().toString());
                }
            }
        });
        return view;
    }
    void ext(final String email, final String password) {
        {

            showProgressDialog();
            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://madarnets.com/WS/SadnWSAndroid.asmx/CheckCustomerLogin", new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {

                    Log.e("JSON Response", s);
                    //dialog.dismiss();
                    hideProgressDialog();
                     if (s.equals("-1")){
                        Toast.makeText(getActivity(),R.string.wrong_email_passord,Toast.LENGTH_SHORT).show();
                    }
                    else if (s.equals("-2")){
                         Toast.makeText(getActivity(),R.string.needs_activation,Toast.LENGTH_SHORT).show();

                     }
                    else {
                        SharedPreferences preferences = getActivity().getSharedPreferences("user_id", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("user_id",""+s);
                         if (rememberme.isChecked()){
                             editor.putBoolean("remember", true);
                         }
                        editor.commit();

                         display_dialog();

                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {

                    //loading.dismiss();
                    Log.e("JSON Error", volleyError.toString());
                    Toast.makeText(getActivity(), "Error:" + volleyError.toString(), Toast.LENGTH_LONG).show();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("KEY","qsefthuko!@#456&*(PLIJYGRDWA");
                    parms.put("emailAddress", email + "");
                    parms.put("password", password + "");
                    return parms;
                }
            };

            stringRequest.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 10000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 10000;
                }

                @Override
                public void retry(VolleyError volleyError) throws VolleyError {

                }
            });
            MySingleTon.getInstance(getActivity()).addToRequestQueue(stringRequest);
        }
    }
    void show_message(String msg){
        Toast.makeText(getActivity(),""+msg,Toast.LENGTH_SHORT).show();
    }
    private void showProgressDialog() {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(getActivity());
            mProgressDialog.setMessage("loading");
            mProgressDialog.setIndeterminate(true);
        }

        mProgressDialog.show();
    }

    private void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.hide();
        }
    }
    void display_dialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View dialog = getActivity().getLayoutInflater().inflate(R.layout.profile_create_dialog,null);
        TextView buttons = (TextView) dialog.findViewById(R.id.buttons);
        TextView exit______ = (TextView) dialog.findViewById(R.id.exit______);
        exit______.setText(R.string.login_success);
        TextView description = (TextView) dialog.findViewById(R.id.description);
        description.setText(R.string.login_detail);
        builder.setView(dialog);
        final AlertDialog alertDialog = builder.create();
        alertDialog.setCancelable(false);
        buttons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
                if (Detail.fa!=null)
                Detail.fa.finish();
                if (Sign_up.fa!=null)
                Sign_up.fa.finish();
                if (Select_Category.fa!=null)
                Select_Category.fa.finish();
                MainActivity.home_click();
            }
        });
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        alertDialog.show();
    }
}
